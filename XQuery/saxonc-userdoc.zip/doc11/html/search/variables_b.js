var searchData=
[
  ['xdmatomicclass_550',['xdmAtomicClass',['../classSaxonProcessor.html#a42e4ee2403c2eb5b13bc04469db6940c',1,'SaxonProcessor']]],
  ['xdmsize_551',['xdmSize',['../classXdmValue.html#a65e3d62ce4c545445bfc1010091ea279',1,'XdmValue']]],
  ['xdmvalue_552',['xdmvalue',['../structsxnc__value.html#a75add1b72763468aa4e21a8bff4b9176',1,'sxnc_value']]]
];
