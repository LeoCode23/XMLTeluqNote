var searchData=
[
  ['_7edocumentbuilder_260',['~DocumentBuilder',['../classDocumentBuilder.html#a78f53ef355bbc27486c02ce1a8f635eb',1,'DocumentBuilder']]],
  ['_7esaxonapiexception_261',['~SaxonApiException',['../classSaxonApiException.html#ae92d16af6fbe32e0dc52afc551a420be',1,'SaxonApiException']]],
  ['_7esaxonprocessor_262',['~SaxonProcessor',['../classSaxonProcessor.html#acd45767a39fb8fb0990ce820116177a6',1,'SaxonProcessor']]],
  ['_7exdmarray_263',['~XdmArray',['../classXdmArray.html#a1290276611656bb4d342a93ae6e11b12',1,'XdmArray']]],
  ['_7exdmatomicvalue_264',['~XdmAtomicValue',['../classXdmAtomicValue.html#a4baa95e13e8fa980a7656ba3678cfde0',1,'XdmAtomicValue']]],
  ['_7exdmfunctionitem_265',['~XdmFunctionItem',['../classXdmFunctionItem.html#a6bc20f90e8382ac392d8c988b30178b2',1,'XdmFunctionItem']]],
  ['_7exdmitem_266',['~XdmItem',['../classXdmItem.html#ae181b1dfd1d758384c5111c814c651d3',1,'XdmItem']]],
  ['_7exdmmap_267',['~XdmMap',['../classXdmMap.html#a09100e9ea9de89412504daa064095ecc',1,'XdmMap']]],
  ['_7exdmnode_268',['~XdmNode',['../classXdmNode.html#af6498effced3b49427d046849c43f01f',1,'XdmNode']]],
  ['_7exdmvalue_269',['~XdmValue',['../classXdmValue.html#a8f4d7661b1ab8a26db2addfe70c3a032',1,'XdmValue']]]
];
