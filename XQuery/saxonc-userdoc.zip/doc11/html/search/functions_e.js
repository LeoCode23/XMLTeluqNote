var searchData=
[
  ['validate_499',['validate',['../classSchemaValidator.html#a7211641ae7ce95d917def33e3dea9a7a',1,'SchemaValidator']]],
  ['validatetonode_500',['validateToNode',['../classSchemaValidator.html#aa8b68f29916c7e406f069f441e0649bd',1,'SchemaValidator']]],
  ['values_501',['values',['../classXdmArray.html#ad50fb35a03c277575ab5de673fa4ffe4',1,'XdmArray::values()'],['../classXdmMap.html#aa8a6c3c49c9a25c3c9b2168b14f8f99f',1,'XdmMap::values()']]],
  ['valuesaslist_502',['valuesAsList',['../classXdmMap.html#aa108dd24bef461b2188449e452a32774',1,'XdmMap']]],
  ['version_503',['version',['../classSaxonProcessor.html#aa33d65639445737792836cc3ddd19e34',1,'SaxonProcessor']]]
];
