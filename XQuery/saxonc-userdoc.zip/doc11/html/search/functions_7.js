var searchData=
[
  ['makearray_417',['makeArray',['../classSaxonProcessor.html#a4ade5788af1747fc2626cb9271f7d998',1,'SaxonProcessor::makeArray(short *input, int length)'],['../classSaxonProcessor.html#a50d323e6b1524b40421631f5f1dc30ee',1,'SaxonProcessor::makeArray(int *input, int length)'],['../classSaxonProcessor.html#abd16bca1b2a6d25a8293f9e812fe93c4',1,'SaxonProcessor::makeArray(long *input, int length)'],['../classSaxonProcessor.html#aa32dce72b601d643044e03bb10010f7a',1,'SaxonProcessor::makeArray(bool *input, int length)'],['../classSaxonProcessor.html#af77de1a7726afe3224514ce06ff56875',1,'SaxonProcessor::makeArray(XdmValue **values, int length)'],['../classSaxonProcessor.html#ae3f8f521ceba26a7b3873906cabb7a85',1,'SaxonProcessor::makeArray(const char **input, int length)']]],
  ['makeatomicvalue_418',['makeAtomicValue',['../classSaxonProcessor.html#a274457f64871e9fae74a59c106b6a225',1,'SaxonProcessor']]],
  ['makebooleanvalue_419',['makeBooleanValue',['../classSaxonProcessor.html#a474db3993ca0f225234e541b8e2492db',1,'SaxonProcessor']]],
  ['makedoublevalue_420',['makeDoubleValue',['../classSaxonProcessor.html#a6fb3fc4765ad722170b8975a68519681',1,'SaxonProcessor']]],
  ['makefloatvalue_421',['makeFloatValue',['../classSaxonProcessor.html#a020233d76ce8cee509e67375b9c190f4',1,'SaxonProcessor']]],
  ['makeintegervalue_422',['makeIntegerValue',['../classSaxonProcessor.html#a74fe3c0f7c8528a978699251274a8697',1,'SaxonProcessor']]],
  ['makelongvalue_423',['makeLongValue',['../classSaxonProcessor.html#ac6c25a3eb8d3c17cc09824aa4e72e7a4',1,'SaxonProcessor']]],
  ['makemap_424',['makeMap',['../classSaxonProcessor.html#ae31599db5d4d599daab10abfb56f05cd',1,'SaxonProcessor']]],
  ['makemap2_425',['makeMap2',['../classSaxonProcessor.html#a3cc25511ed505613b5b7a9d5f63f9a2f',1,'SaxonProcessor']]],
  ['makemap3_426',['makeMap3',['../classSaxonProcessor.html#a12e031354bb2892b07145396739d7a5c',1,'SaxonProcessor']]],
  ['makeqnamevalue_427',['makeQNameValue',['../classSaxonProcessor.html#a65693c78afc28c1df3a4e682885ac566',1,'SaxonProcessor']]],
  ['makestringvalue_428',['makeStringValue',['../classSaxonProcessor.html#afe07f146121f771102eb9d79549c711d',1,'SaxonProcessor::makeStringValue(std::string str)'],['../classSaxonProcessor.html#a6a1c98c83fd43e7604c1d9ba81f30bc1',1,'SaxonProcessor::makeStringValue(const char *str)']]],
  ['makestringvalue2_429',['makeStringValue2',['../classSaxonProcessor.html#a29a4aa6b61170e9f32ca04baa105fe0f',1,'SaxonProcessor']]],
  ['mapsize_430',['mapSize',['../classXdmMap.html#a8dbddf62b212e948241b778e07e23546',1,'XdmMap']]]
];
