var searchData=
[
  ['parameters_145',['parameters',['../classSaxonProcessor.html#a61fb47a7c0a92abf5ccff527a1370250',1,'SaxonProcessor']]],
  ['parsexmlfromfile_146',['parseXmlFromFile',['../classDocumentBuilder.html#a4fd6acc79cbed4ae3aa9bd062ffa080f',1,'DocumentBuilder::parseXmlFromFile()'],['../classSaxonProcessor.html#a11c87070b938db1a89862ed791ba455f',1,'SaxonProcessor::parseXmlFromFile()']]],
  ['parsexmlfromstring_147',['parseXmlFromString',['../classDocumentBuilder.html#afa5893f8d528ca8b5683a789048e0e9c',1,'DocumentBuilder::parseXmlFromString()'],['../classSaxonProcessor.html#aa11cb90f1eb3c9de2dde93d418107525',1,'SaxonProcessor::parseXmlFromString()']]],
  ['parsexmlfromuri_148',['parseXmlFromUri',['../classDocumentBuilder.html#ab63836c2aed10d5b9cc3a13e8080c77b',1,'DocumentBuilder::parseXmlFromUri()'],['../classSaxonProcessor.html#a2908468907bcabb23fd1362d2ab79718',1,'SaxonProcessor::parseXmlFromUri(const char *source, SchemaValidator *validator=nullptr)']]],
  ['proc_149',['proc',['../classSaxonProcessor.html#ad68c5004e92c9e766dee3066451fad62',1,'SaxonProcessor']]],
  ['procclass_150',['procClass',['../classSaxonProcessor.html#a79449aedf4cd2ab4cf21ab3747c7438d',1,'SaxonProcessor']]],
  ['put_151',['put',['../classXdmArray.html#a7179c3187137915d024ea8e2834dc312',1,'XdmArray::put()'],['../classXdmMap.html#a1fb099c70aefb55e1314e510d0c33301',1,'XdmMap::put()']]]
];
