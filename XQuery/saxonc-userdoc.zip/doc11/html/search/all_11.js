var searchData=
[
  ['validate_223',['validate',['../classSchemaValidator.html#a7211641ae7ce95d917def33e3dea9a7a',1,'SchemaValidator']]],
  ['validatetonode_224',['validateToNode',['../classSchemaValidator.html#aa8b68f29916c7e406f069f441e0649bd',1,'SchemaValidator']]],
  ['value_225',['value',['../structsxnc__parameter.html#aa745d7bb87169719c7ee41377296def5',1,'sxnc_parameter::value()'],['../structsxnc__property.html#a2a8369435bdf94221408f1713350f9ac',1,'sxnc_property::value()'],['../classXdmItem.html#afae16d0fd8520c70a0968b10c33e401a',1,'XdmItem::value()']]],
  ['values_226',['values',['../classXdmValue.html#ae2f9c0fdcdc66a379c4be038a0eea35b',1,'XdmValue::values()'],['../classXdmArray.html#ad50fb35a03c277575ab5de673fa4ffe4',1,'XdmArray::values()'],['../classXdmMap.html#aa8a6c3c49c9a25c3c9b2168b14f8f99f',1,'XdmMap::values()']]],
  ['valuesaslist_227',['valuesAsList',['../classXdmMap.html#aa108dd24bef461b2188449e452a32774',1,'XdmMap']]],
  ['valuetype_228',['valueType',['../classXdmValue.html#ad09d3c7ec75b82f4839be029541dce3b',1,'XdmValue']]],
  ['version_229',['version',['../classSaxonProcessor.html#aa33d65639445737792836cc3ddd19e34',1,'SaxonProcessor']]],
  ['versionclass_230',['versionClass',['../classSaxonProcessor.html#a22a56c6dd1e9cf8d99b997beb7bd6af6',1,'SaxonProcessor']]],
  ['versionstr_231',['versionStr',['../classSaxonProcessor.html#ac43e6c3ada14bbe5c75d31d4bc05f831',1,'SaxonProcessor']]]
];
