var searchData=
[
  ['name_532',['name',['../structsxnc__parameter.html#ad69dc2d79428643ed7221919a151c829',1,'sxnc_parameter::name()'],['../structsxnc__property.html#a6a7cbb5399c5b196b84971b509b8223c',1,'sxnc_property::name()']]],
  ['namespacei_533',['namespacei',['../structsxnc__parameter.html#a346999df2429bcaa17192b0d06586623',1,'sxnc_parameter']]],
  ['nativemethods_534',['nativeMethods',['../classSaxonProcessor.html#a9d3e514566eb2cdd07317cbc71a16d8d',1,'SaxonProcessor']]],
  ['nativemethodvect_535',['nativeMethodVect',['../classSaxonProcessor.html#ae179d0116491591533e9692e3f462962',1,'SaxonProcessor']]]
];
