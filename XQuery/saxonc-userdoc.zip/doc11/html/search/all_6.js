var searchData=
[
  ['importschemanamespace_102',['importSchemaNamespace',['../classXPathProcessor.html#afc746a4feeee271d565c846a980321c5',1,'XPathProcessor']]],
  ['incrementrefcount_103',['incrementRefCount',['../classXdmItem.html#acb3002dc5b8524715ebd16167b2b77c2',1,'XdmItem::incrementRefCount()'],['../classXdmValue.html#abf6de21eaf35e82506e7d812cb7993c0',1,'XdmValue::incrementRefCount()']]],
  ['initialize_104',['initialize',['../classXdmValue.html#ad286427e639f73693442dea26806bfda',1,'XdmValue']]],
  ['isarray_105',['isArray',['../classXdmArray.html#aa3d452b6119170b88bb816868af35a61',1,'XdmArray::isArray()'],['../classXdmItem.html#a5c40c95dcd64668294b2b0593e09a4c0',1,'XdmItem::isArray()']]],
  ['isatomic_106',['isAtomic',['../classXdmAtomicValue.html#abb4184a51428e341a1834d425fc9e31b',1,'XdmAtomicValue::isAtomic()'],['../classXdmFunctionItem.html#ad2be6aa4c4b2f8c92319cf5fb7601615',1,'XdmFunctionItem::isAtomic()'],['../classXdmItem.html#ae71fc9eda4bec6abf597e4abb4efdc30',1,'XdmItem::isAtomic()'],['../classXdmNode.html#a7fd5a4c3325c71149d86849d232d4293',1,'XdmNode::isAtomic()']]],
  ['isdtdvalidation_107',['isDTDValidation',['../classDocumentBuilder.html#aae746f0323b857651cb0a16e4cbeadce',1,'DocumentBuilder']]],
  ['isempty_108',['isEmpty',['../classXdmMap.html#a78aae85591973969360997f609198abf',1,'XdmMap']]],
  ['isfunction_109',['isFunction',['../classXdmArray.html#a635550e49a9e4490d9f341e0005edfb3',1,'XdmArray::isFunction()'],['../classXdmMap.html#a65be2339354acbb1f2b72db0beaa46ad',1,'XdmMap::isFunction()'],['../classXdmItem.html#a0cf4927ad0c585f87d16fbbc0efcacaf',1,'XdmItem::isFunction()'],['../classXdmFunctionItem.html#a7f597dc73fa85a0e537e398969166c49',1,'XdmFunctionItem::isFunction()']]],
  ['islinenumbering_110',['isLineNumbering',['../classDocumentBuilder.html#a89d90f676b8bcf72afe008c25c5c09b1',1,'DocumentBuilder']]],
  ['ismap_111',['isMap',['../classXdmItem.html#a361fefc83b876ef45aa91dc6600f329f',1,'XdmItem::isMap()'],['../classXdmMap.html#ab09e8af37540308cbb50ac19950a3509',1,'XdmMap::isMap()']]],
  ['isnode_112',['isNode',['../classXdmItem.html#a04dd58bb194f9b388e5b5ddd6b9b06ee',1,'XdmItem::isNode()'],['../classXdmNode.html#a7ab4fbb5cb32dac8ec7c6e7525185696',1,'XdmNode::isNode()']]],
  ['isschemaawareprocessor_113',['isSchemaAwareProcessor',['../classSaxonProcessor.html#ad307e868b687e828d1e91a8ff0ba8fcd',1,'SaxonProcessor']]],
  ['itemat_114',['itemAt',['../classXdmItem.html#a2604f743213a1be2a4c82b5e26b75dcd',1,'XdmItem::itemAt()'],['../classXdmValue.html#abc81675fb0ea239dae0fab0382c6c6a7',1,'XdmValue::itemAt()']]]
];
