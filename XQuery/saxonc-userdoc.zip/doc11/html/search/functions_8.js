var searchData=
[
  ['newdocumentbuilder_431',['newDocumentBuilder',['../classSaxonProcessor.html#ae035ec17053a838d89de4c8b6a3d4673',1,'SaxonProcessor']]],
  ['newschemavalidator_432',['newSchemaValidator',['../classSaxonProcessor.html#a6692d2c60fdb15e6c1928e829f5b2ce2',1,'SaxonProcessor']]],
  ['newxpathprocessor_433',['newXPathProcessor',['../classSaxonProcessor.html#af7db70c9aabd761461aaf33c093db47e',1,'SaxonProcessor']]],
  ['newxqueryprocessor_434',['newXQueryProcessor',['../classSaxonProcessor.html#aa01f9f1ce33268f947b9151c59fd3ed0',1,'SaxonProcessor']]],
  ['newxslt30processor_435',['newXslt30Processor',['../classSaxonProcessor.html#ab3be9588c899cafea40982df0bb49be5',1,'SaxonProcessor']]]
];
