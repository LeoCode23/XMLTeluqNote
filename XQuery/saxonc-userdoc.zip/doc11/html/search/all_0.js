var searchData=
[
  ['addmember_0',['addMember',['../classXdmArray.html#a1afd467c0b4c0490753f774b942e9e27',1,'XdmArray']]],
  ['addnativemethod_1',['addNativeMethod',['../classSaxonProcessor.html#a3be690694e77db9c05438c4ff4751db0',1,'SaxonProcessor']]],
  ['addunderlyingvalue_2',['addUnderlyingValue',['../classXdmValue.html#a5d1a7f165125b23554d407abd62e6c77',1,'XdmValue']]],
  ['addxdmitem_3',['addXdmItem',['../classXdmValue.html#a7c3781a7b5cbeafa2d469fc5a7a4aed1',1,'XdmValue']]],
  ['addxdmvaluewithtype_4',['addXdmValueWithType',['../classXdmValue.html#a7a429909ea9000fa30f460ebbfa3c6e8',1,'XdmValue']]],
  ['applytemplatesreturningfile_5',['applyTemplatesReturningFile',['../classXsltExecutable.html#a4f69fa806b817a5fb7de098d691551e9',1,'XsltExecutable']]],
  ['applytemplatesreturningstring_6',['applyTemplatesReturningString',['../classXsltExecutable.html#a875ddf770627249ae16ad136957b8550',1,'XsltExecutable']]],
  ['applytemplatesreturningvalue_7',['applyTemplatesReturningValue',['../classXsltExecutable.html#a050304053964d3934f53aebe26cbd451',1,'XsltExecutable']]],
  ['arraylength_8',['arrayLength',['../classXdmArray.html#aa260c6855292f4156f4eff474e57324e',1,'XdmArray']]],
  ['aslist_9',['asList',['../classXdmArray.html#a5fbfc466f6c475e42e9ead9dc3f1556a',1,'XdmArray']]]
];
