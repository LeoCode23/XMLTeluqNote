var searchData=
[
  ['objectarray_536',['objectArray',['../structJParameters.html#a51b45222b4e79154eb3c0a97c47cf7f6',1,'JParameters']]]
];
