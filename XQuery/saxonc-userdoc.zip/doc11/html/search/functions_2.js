var searchData=
[
  ['declarenamespace_343',['declareNamespace',['../classXPathProcessor.html#acd7d41ee158550a5f8dd1c54cfed005f',1,'XPathProcessor::declareNamespace()'],['../classXQueryProcessor.html#a7fe95c361f4e2dba359d659bafd98d55',1,'XQueryProcessor::declareNamespace()']]],
  ['declarevariable_344',['declareVariable',['../classXPathProcessor.html#aadddf8f741011599a10e47beed2c3579',1,'XPathProcessor']]],
  ['decrementrefcount_345',['decrementRefCount',['../classXdmItem.html#adf60c4f2881f314c97afc44c4371c548',1,'XdmItem::decrementRefCount()'],['../classXdmValue.html#acc9a039f318c591ec699a57e70a05311',1,'XdmValue::decrementRefCount()']]],
  ['deletexdmvaluearray_346',['deleteXdmValueArray',['../classXslt30Processor.html#aa3d5689c592d4b43c6a30778809c9ef1',1,'Xslt30Processor::deleteXdmValueArray()'],['../classXsltExecutable.html#aec5babc65d703bccb608a2ab5900c096',1,'XsltExecutable::deleteXdmValueArray()']]]
];
