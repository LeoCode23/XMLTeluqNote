var searchData=
[
  ['registercppfunction_441',['registerCPPFunction',['../classSaxonProcessor.html#a847fb5d5aa804c9a0727f71d5327aee6',1,'SaxonProcessor']]],
  ['registernativemethods_442',['registerNativeMethods',['../classSaxonProcessor.html#a83e96760c818568b665538746b93d526',1,'SaxonProcessor']]],
  ['registerschemafromfile_443',['registerSchemaFromFile',['../classSchemaValidator.html#a2f376f07ebc8bd8ab975fa5977b76138',1,'SchemaValidator']]],
  ['registerschemafromstring_444',['registerSchemaFromString',['../classSchemaValidator.html#ac42414a188f52ee92224545b2b043de8',1,'SchemaValidator']]],
  ['release_445',['release',['../classSaxonProcessor.html#a262fa0d2920ebb8147aafbcbac5982e1',1,'SaxonProcessor']]],
  ['releasexdmvalue_446',['releaseXdmValue',['../classXdmValue.html#aec46e4fcc275aa3d38afa810eb2908c2',1,'XdmValue']]],
  ['remove_447',['remove',['../classXdmMap.html#a9f66a55ec7e6cfc5b8fed161435b80b6',1,'XdmMap']]],
  ['removeparameter_448',['removeParameter',['../classSchemaValidator.html#afaa74f20e4cd9536e3fe0fd47d71bb4c',1,'SchemaValidator::removeParameter()'],['../classXPathProcessor.html#a326ab5ea3ae70ac3fd8a44aedf3fba83',1,'XPathProcessor::removeParameter()'],['../classXQueryProcessor.html#ae2b477cf8d5fc7785209239937ca420c',1,'XQueryProcessor::removeParameter()'],['../classXslt30Processor.html#a1771da071685b835cbb6235b421c9c4e',1,'Xslt30Processor::removeParameter()'],['../classXsltExecutable.html#a70339d8be3f650b32233c8cd2d765435',1,'XsltExecutable::removeParameter(const char *name)']]],
  ['removeproperty_449',['removeProperty',['../classXsltExecutable.html#afa102e7fe0b50fa1a2c6fa6517e8332b',1,'XsltExecutable']]],
  ['runquerytofile_450',['runQueryToFile',['../classXQueryProcessor.html#a4766c717c62846ed4e7494dad465c21a',1,'XQueryProcessor']]],
  ['runquerytostring_451',['runQueryToString',['../classXQueryProcessor.html#aae0275dd64f0e6dfcf74e88a84c4f471',1,'XQueryProcessor']]],
  ['runquerytovalue_452',['runQueryToValue',['../classXQueryProcessor.html#a8410d0f5a588b4ed4c8fd7df6cd56fd4',1,'XQueryProcessor']]]
];
