var searchData=
[
  ['saxoncapiclass_541',['saxonCAPIClass',['../classSaxonProcessor.html#ad2da9e8e78e94d51ce417dda2350d36f',1,'SaxonProcessor']]],
  ['stringarray_542',['stringArray',['../structJParameters.html#a27f91843e496c4f32e6a756422021b72',1,'JParameters']]],
  ['stringvalue_543',['stringValue',['../classXdmItem.html#af4c550dc0064761623eb96b865d25332',1,'XdmItem']]],
  ['sxn_5fenviron_544',['sxn_environ',['../classSaxonProcessor.html#a3c9a4c030d364137bdfc8d1c98bcdb84',1,'SaxonProcessor']]]
];
