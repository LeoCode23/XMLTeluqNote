var searchData=
[
  ['parsexmlfromfile_437',['parseXmlFromFile',['../classDocumentBuilder.html#a4fd6acc79cbed4ae3aa9bd062ffa080f',1,'DocumentBuilder::parseXmlFromFile()'],['../classSaxonProcessor.html#a11c87070b938db1a89862ed791ba455f',1,'SaxonProcessor::parseXmlFromFile()']]],
  ['parsexmlfromstring_438',['parseXmlFromString',['../classDocumentBuilder.html#afa5893f8d528ca8b5683a789048e0e9c',1,'DocumentBuilder::parseXmlFromString()'],['../classSaxonProcessor.html#aa11cb90f1eb3c9de2dde93d418107525',1,'SaxonProcessor::parseXmlFromString()']]],
  ['parsexmlfromuri_439',['parseXmlFromUri',['../classDocumentBuilder.html#ab63836c2aed10d5b9cc3a13e8080c77b',1,'DocumentBuilder::parseXmlFromUri()'],['../classSaxonProcessor.html#a2908468907bcabb23fd1362d2ab79718',1,'SaxonProcessor::parseXmlFromUri()']]],
  ['put_440',['put',['../classXdmArray.html#a7179c3187137915d024ea8e2834dc312',1,'XdmArray::put()'],['../classXdmMap.html#a1fb099c70aefb55e1314e510d0c33301',1,'XdmMap::put()']]]
];
