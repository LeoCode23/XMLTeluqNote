var searchData=
[
  ['operator_3d_436',['operator=',['../classSaxonProcessor.html#ad70800a27fee44c706f58e4de3c28935',1,'SaxonProcessor']]]
];
