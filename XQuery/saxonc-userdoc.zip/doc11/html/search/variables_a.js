var searchData=
[
  ['value_545',['value',['../structsxnc__parameter.html#aa745d7bb87169719c7ee41377296def5',1,'sxnc_parameter::value()'],['../structsxnc__property.html#a2a8369435bdf94221408f1713350f9ac',1,'sxnc_property::value()'],['../classXdmItem.html#afae16d0fd8520c70a0968b10c33e401a',1,'XdmItem::value()']]],
  ['values_546',['values',['../classXdmValue.html#ae2f9c0fdcdc66a379c4be038a0eea35b',1,'XdmValue']]],
  ['valuetype_547',['valueType',['../classXdmValue.html#ad09d3c7ec75b82f4839be029541dce3b',1,'XdmValue']]],
  ['versionclass_548',['versionClass',['../classSaxonProcessor.html#a22a56c6dd1e9cf8d99b997beb7bd6af6',1,'SaxonProcessor']]],
  ['versionstr_549',['versionStr',['../classSaxonProcessor.html#ac43e6c3ada14bbe5c75d31d4bc05f831',1,'SaxonProcessor']]]
];
