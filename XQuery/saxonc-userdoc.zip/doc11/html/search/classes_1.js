var searchData=
[
  ['jparameters_271',['JParameters',['../structJParameters.html',1,'']]]
];
