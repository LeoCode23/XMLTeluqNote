var searchData=
[
  ['refcount_540',['refCount',['../classXdmValue.html#a513ad6226980b1882bcc7ef247162bce',1,'XdmValue']]]
];
